﻿-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2016-01-21 16:48:50.125



CREATE DATABASE TUANCDPH03640_QLBH
GO
-- tables
-- Table: chitiethoadon
CREATE TABLE chitiethoadon (
    mahd varchar(20)  NOT NULL,
    masp varchar(20)  NOT NULL,
    soluong int  NOT NULL
)
;





-- Table: hoadon
CREATE TABLE hoadon (
    mahd varchar(20)  NOT NULL,
    giasp decimal(12,2)  NOT NULL,
    makh varchar(20)  NOT NULL,
    CONSTRAINT hoadon_pk PRIMARY KEY  (mahd)
)
;





-- Table: khachhang
CREATE TABLE khachhang (
    makh varchar(20)  NOT NULL,
    tenkh nvarchar(20)  NOT NULL,
    email varchar(30)  NOT NULL,
    diachi nvarchar(50)  NOT NULL,
    sdt int  NULL,
    CONSTRAINT khachhang_pk PRIMARY KEY  (makh)
)
;





-- Table: loaisanpham
CREATE TABLE loaisanpham (
    maloaisp varchar(20)  NOT NULL,
    tenloaisp nvarchar(20)  NOT NULL,
    CONSTRAINT loaisanpham_pk PRIMARY KEY  (maloaisp)
)
;





-- Table: sanpham
CREATE TABLE sanpham (
    masp varchar(20)  NOT NULL,
    maloaisp varchar(20)  NOT NULL,
    donvitinh nvarchar(20)  NOT NULL,
    tensp nvarchar(20)  NOT NULL,
    giasp decimal(12,2)  NOT NULL,
    motasp nvarchar(1000)  NOT NULL,
    img image   NULL,
    CONSTRAINT sanpham_pk PRIMARY KEY  (masp)
)
;









-- foreign keys
-- Reference:  client_purchase (table: hoadon)

ALTER TABLE hoadon ADD CONSTRAINT client_purchase 
    FOREIGN KEY (makh)
    REFERENCES khachhang (makh)
;

-- Reference:  product_category_product (table: sanpham)

ALTER TABLE sanpham ADD CONSTRAINT product_category_product 
    FOREIGN KEY (maloaisp)
    REFERENCES loaisanpham (maloaisp)
;

-- Reference:  product_purchase_item (table: chitiethoadon)

ALTER TABLE chitiethoadon ADD CONSTRAINT product_purchase_item 
    FOREIGN KEY (masp)
    REFERENCES sanpham (masp)
;

-- Reference:  purchase_purchase_item (table: chitiethoadon)

ALTER TABLE chitiethoadon ADD CONSTRAINT purchase_purchase_item 
    FOREIGN KEY (mahd)
    REFERENCES hoadon (mahd)
;





-- End of file.

--nhập dữ liêu
---bảng khách hang

INSERT INTO khachhang VALUES ('MAKH01',N'TRẦN QUANG ĐẠT','DATQTPH04025@fpt.edu.vn',N'24 cầu giấy',null)
INSERT INTO khachhang VALUES ('MAKH02',N'TRẦN THI HẰNG','HANGTTPH03834@fpt.edu.vn',N'24 đống đa',null)
INSERT INTO khachhang VALUES ('MAKH03',N'TRẦN THỊ HOA','HOATT@gmail.com',N'20 ba đình',null)
INSERT INTO khachhang VALUES ('MAKH04',N'TRẦN VĂN QUYẾT','quyettv@gmail.com',N'13  cầu giấy',null)
INSERT INTO khachhang VALUES ('MAKH05',N'NGUYỄN QUANG TIẾN','tiennq@gmail.com',N'10 trần duy hưng',null)
---bảng hóa đơn

INSERT INTO hoadon VALUES ('MAHD01','1000000','MAKH01')
INSERT INTO hoadon VALUES ('MAHD02','2500000','MAKH02')
INSERT INTO hoadon VALUES ('MAHD03','500000','MAKH03')
INSERT INTO hoadon VALUES ('MAHD04','70000','MAKH04')
INSERT INTO hoadon VALUES ('MAHD05','200000','MAKH05')
--- BẢNG loại sản phẩm

INSERT INTO loaisanpham VALUES ('WP-S2',N'QUẠT ĐIỆN')
INSERT INTO loaisanpham VALUES ('WDC-01',N'NẦU CƠM ĐIỆN')
INSERT INTO loaisanpham VALUES ('SDO-CX09',N'MÁY TÍNH')
INSERT INTO loaisanpham VALUES ('WP-ASD03',N'MÁY GIẶT')
INSERT INTO loaisanpham VALUES ('SER-SQL009',N'ĐÈN HỌC')
--bảng sản phẩm

INSERT INTO sanpham VALUES ('MASP01','WP-S2 ',N' chiếc',N'quạt điện','1000000',N'rất đẹp',null)
INSERT INTO sanpham VALUES ('MASP02','WDC-01 ',N' chiếc',N'NỒI CƠM ĐIỆN','2500000',N'ĐẸP VÀ TỐT',null)
INSERT INTO sanpham VALUES ('MASP03','SDO-CX09 ',N' chiếc',N'MÁY TÍNH','500000',N'CHẤT LƯỢNG CAO',null)
INSERT INTO sanpham VALUES ('MASP04','WP-ASD03',N' chiếc',N'MÁY GIẶT','70000',N' TÍNH NĂNG',null)
INSERT INTO sanpham VALUES ('MASP05','SER-SQL009',N' chiếc',N'ĐÈN HỌC','200000',N'DỄ SỬ DỤNG',null)
---BẢNG CHI TIẾT HÓA ĐƠN

INSERT INTO chitiethoadon VALUES ('MAHD01','MASP01',1)
INSERT INTO chitiethoadon VALUES ('MAHD02','MASP02',2)
INSERT INTO chitiethoadon VALUES ('MAHD03','MASP03',4)
INSERT INTO chitiethoadon VALUES ('MAHD04','MASP05',8)
INSERT INTO chitiethoadon VALUES ('MAHD05','MASP05',6)
SELECT *FROM khachhang
select*from hoadon
SELECT *FROM loaisanpham
select *from sanpham
SELECT*FROM chitiethoadon

